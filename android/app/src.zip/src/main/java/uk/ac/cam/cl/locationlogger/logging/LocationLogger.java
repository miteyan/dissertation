package uk.ac.cam.cl.locationlogger.logging;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import uk.ac.cam.cl.locationlogger.ApplicationConstants;
import uk.ac.cam.cl.locationlogger.location.LocationTrackerActivity;

public class LocationLogger {
    public static final int BUFFER_SIZE = 1024;
    public static String filename = "location_log";
    public static String extension = ".log";

    public static synchronized void log(String s, Context context) {
        FileOutputStream fos = null;
        String file = filename + extension;
        try {
            fos = context.openFileOutput(file, Context.MODE_APPEND);
            fos.write(s.getBytes());
            FileLogger.log("Logging location: " + s, context);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
                // Try to upload, if it is time and we have WiFi
                if (System.currentTimeMillis() - getLastUploadTime(context) >
                        ApplicationConstants.UPLOAD_INTERVAL_MILLIS) {
                    // If we are using on-phone graph computation, update the stored graph here
                    // (Functionality not yet implemented :))
                    // NB you will want to transfer the GRAPH, not the log file, to avoid
                    // transmitting sensitive data -- change the upload methods.
                    //GraphUtils.updateGraphFromLogFile(new File(file), context);
                    NetworkInfo info = ((ConnectivityManager) context
                            .getSystemService(Context.CONNECTIVITY_SERVICE))
                            .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                    boolean isWifiConnected =
                            info != null && info.isAvailable() && info.isConnected();
                    if (isWifiConnected) {
                        tryToUpload(context, file);
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void tryToUpload(Context context, String file) throws IOException {
        Bundle bundle = new Bundle();
        bundle.putBoolean(ContentResolver.SYNC_EXTRAS_MANUAL, true);
        bundle.putBoolean(ContentResolver.SYNC_EXTRAS_EXPEDITED, true);

        String user = LocationTrackerActivity.getUserID(context);
        // Location files
        File file2 = new File(user + '_' + filename + '_' + System.currentTimeMillis() +
                extension);
        zip(file, file2.getName() + ".zip", context);
        if (ApplicationConstants.DEBUG) {
            // Log files
            String file3 = FileLogger.filename + FileLogger.extension;
            File file4 = new File(user + '_' + FileLogger.filename + '_' +
                    System.currentTimeMillis() +
                    FileLogger.extension);
            zip(file3, file4.getName() + ".zip", context);
        }
        FileLogger.log("Making sync request.", context);
        ContentResolver.requestSync(LocationTrackerActivity.getUserAccount(context),
                LocationTrackerActivity.AUTHORITY, bundle);
    }

    private static void zip(String file, String zipFile, Context context) throws IOException {
        BufferedInputStream origin;
        ZipOutputStream out = new ZipOutputStream(
                new BufferedOutputStream(context.openFileOutput(zipFile, Context.MODE_APPEND)));
        try {
            byte data[] = new byte[BUFFER_SIZE];
            FileInputStream fi = context.openFileInput(file);
            origin = new BufferedInputStream(fi, BUFFER_SIZE);
            try {
                ZipEntry entry = new ZipEntry(file.substring(file.lastIndexOf("/") + 1));
                out.putNextEntry(entry);
                int count;
                while ((count = origin.read(data, 0, BUFFER_SIZE)) != -1) {
                    out.write(data, 0, count);
                }
            } finally {
                origin.close();
            }
        } finally {
            out.close();
        }
    }

    private static long getLastUploadTime(Context context) {
        SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        return sPrefs.getLong(ApplicationConstants.KEY_UPLOAD_TIME, 0L);
    }

}

package uk.ac.cam.cl.locationlogger.location;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.widget.Toast;

import com.commonsware.cwac.wakeful.WakefulIntentService;

import java.util.UUID;

import uk.ac.cam.cl.locationlogger.ApplicationConstants;
import uk.ac.cam.cl.locationlogger.alarms.ServiceAlarm;
import uk.ac.cam.cl.locationlogger.logging.FileLogger;
import uk.ac.cam.cl.locationlogger.test.TestGraphUtils;

public class LocationTrackerActivity extends Activity {

    // The authority for the sync adapter's (dummy) content provider
    public static final String AUTHORITY = "uk.ac.cam.cl.locationlogger.provider";

    public static Account getUserAccount(Context context) {
        // Get the user account (required for sync, doesn't do anything else), or create
        // one if it doesn't exist.
        Account[] accounts = AccountManager.get(context)
                .getAccountsByType(ApplicationConstants.ACCOUNT_TYPE);
        if (accounts.length < 1) {
            return createSyncAccount(UUID.randomUUID().toString(), context);
        }
        else {
            return accounts[0]; // Should only be one account.
        }
    }

    public static String getUserID(Context context) {
        // Get ID for current user, required for file naming.
        SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        return sPrefs.getString(ApplicationConstants.KEY_UUID, null);
    }

    public static Account createSyncAccount(String user, Context context) {
        Account newAccount = new Account(user, ApplicationConstants.ACCOUNT_TYPE);
        AccountManager accountManager = (AccountManager) context.getSystemService(ACCOUNT_SERVICE);
        boolean success = accountManager.addAccountExplicitly(newAccount, null, null);
        if (success) {
            ContentResolver.setIsSyncable(newAccount, AUTHORITY, 1);
            // Only save the user ID if the account was added successfully
            SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = sPrefs.edit();
            editor.putString(ApplicationConstants.KEY_UUID, user);
            editor.commit();
            return newAccount;
        }
        else {
            return null;
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getUserAccount(this.getApplicationContext()) == null) {
            FileLogger.log("Couldn't create user account.", this.getApplicationContext());
            this.finish();
        }
        /* FOR TESTING GRAPH CREATION FROM FILE raw/location_log.log
        AsyncTask.execute(new Runnable() {
            @Override public void run() {
                TestGraphUtils.constructGraph(LocationTrackerActivity.this);
            }
        });
        END FOR TESTING */

        // Check that we have permission to get location, if not, ask for permission.
        int permissionCheck =
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (permissionCheck != PermissionChecker.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    ApplicationConstants.LOCATION_PERMISSIONS_CODE);
        }
        else {
            // Start the location logging service.
            startService(getApplicationContext());
            this.finish();
        }
    }

    @Override protected void onResume() {
        super.onResume();
    }

    @Override protected void onPause() {
        super.onPause();
    }

    @Override public void onRequestPermissionsResult(int requestCode,
                                                     @NonNull String permissions[],
                                                     @NonNull int[] grantResults) {
        FileLogger.log("Processing permissions...", this.getApplicationContext());
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == ApplicationConstants.LOCATION_PERMISSIONS_CODE) {
            // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                FileLogger.log("Starting service...", this.getApplicationContext());
                startService(getApplicationContext());
            }
        }
        this.finish();
    }

    private void startService(final Context context) {
        AsyncTask.execute(new Runnable() {
            @Override public void run() {
                setAlarm(context);
            }
        });
        Intent mServiceIntent = new Intent(this, LocationTrackerService.class);
        WakefulIntentService.sendWakefulWork(context, mServiceIntent);
        CharSequence text = "Location logging now active.";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    private void setAlarm(Context context) {
        ServiceAlarm alarm = new ServiceAlarm();
        LocationTrackerService.scheduleAlarms(alarm, context);
    }

}

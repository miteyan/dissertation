package uk.ac.cam.cl.locationlogger.transfer;

import android.accounts.Account;
import android.content.AbstractThreadedSyncAdapter;
import android.content.ContentProviderClient;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SyncResult;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.File;
import java.io.IOException;

import uk.ac.cam.cl.locationlogger.ApplicationConstants;
import uk.ac.cam.cl.locationlogger.location.LocationTrackerActivity;
import uk.ac.cam.cl.locationlogger.logging.FileLogger;

public class SyncAdapter extends AbstractThreadedSyncAdapter {
    private static final String SERVER_URL = "http://pizza.cl.cam.ac.uk/clb76/receive.php";

    public SyncAdapter(Context context, boolean autoInitialize) {
        super(context, autoInitialize);
    }

    public SyncAdapter(Context context, boolean autoInitialize, boolean allowParallelSyncs) {
        super(context, autoInitialize, allowParallelSyncs);
        FileLogger.log("Initialised sync adapter.", context);

    }

    @Override
    public void onPerformSync(Account account, Bundle bundle, String s, ContentProviderClient
            contentProviderClient, SyncResult syncResult) {
        // Get list of files available
        File directory = this.getContext().getFilesDir();
        File[] names = directory.listFiles();
        Context context = this.getContext();

        FileLogger.log("Syncing.", context);

        ConnectivityManager connMgr =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            try {
                for (File f : names) {
                    String name = f.getName();
                    if (!toSync(name)) {
                        continue; // Only sync the log file
                    }
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost(SERVER_URL);
                    MultipartEntity entity = new MultipartEntity();
                    entity.addPart("fileupload", new FileBody(f));
                    httppost.setEntity(entity);
                    HttpResponse response;
                    response = httpclient.execute(httppost);
                    if (response.getStatusLine().getStatusCode() == 200) {
                        f.delete();
                        setNewUploadTime(context);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean toSync(String filename) {
        String user = LocationTrackerActivity.getUserID(this.getContext());
        return filename.startsWith(user);
    }

    private static void setNewUploadTime(Context context) {
        SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sPrefs.edit();
        editor.putLong(ApplicationConstants.KEY_UPLOAD_TIME, System.currentTimeMillis());
        editor.commit();
    }
}
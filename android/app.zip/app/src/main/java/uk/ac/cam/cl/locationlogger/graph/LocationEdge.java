package uk.ac.cam.cl.locationlogger.graph;

import org.jgrapht.graph.DefaultWeightedEdge;

public class LocationEdge extends DefaultWeightedEdge {
}

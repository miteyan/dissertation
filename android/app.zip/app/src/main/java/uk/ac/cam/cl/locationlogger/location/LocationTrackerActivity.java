package uk.ac.cam.cl.locationlogger.location;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup.LayoutParams;



import com.commonsware.cwac.wakeful.WakefulIntentService;

import java.util.UUID;

import uk.ac.cam.cl.locationlogger.ApplicationConstants;
import uk.ac.cam.cl.locationlogger.alarms.ServiceAlarm;
import uk.ac.cam.cl.locationlogger.logging.FileLogger;
import uk.ac.cam.cl.locationlogger.test.TestGraphUtils;
import uk.ac.cam.cl.locationlogger.R;

public class LocationTrackerActivity extends Activity {

    private static Activity activity;

    private EditText userid_textfield;

    public static String inserted_userid;
    // The authority for the sync adapter's (dummy) content provider
    public static final String AUTHORITY = "uk.ac.cam.cl.locationlogger.provider";

    public static Account getUserAccount(Context context) {
        // Get the user account (required for sync, doesn't do anything else), or create
        // one if it doesn't exist.
        Account[] accounts = AccountManager.get(context).getAccountsByType(ApplicationConstants.ACCOUNT_TYPE);
        if (accounts.length < 1) {
            return createSyncAccount(UUID.randomUUID().toString(), context);
        }
        else {
            return accounts[0]; // Should only be one account.
        }
    }

    public static String getUserID(Context context) {
        // Get ID for current user, required for file naming.
        SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        return sPrefs.getString(ApplicationConstants.KEY_UUID, null);
    }

    public static String getInsertedUserID(Context context) {
        return inserted_userid;
    }


    public static Account createSyncAccount(String user, Context context) {
        Account newAccount = new Account(user, ApplicationConstants.ACCOUNT_TYPE);
        AccountManager accountManager = (AccountManager) context.getSystemService(ACCOUNT_SERVICE);
        boolean success = accountManager.addAccountExplicitly(newAccount, null, null);
        if (success) {
            ContentResolver.setIsSyncable(newAccount, AUTHORITY, 1);
            // Only save the user ID if the account was added successfully
            SharedPreferences sPrefs = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = sPrefs.edit();
            editor.putString(ApplicationConstants.KEY_UUID, user);
            editor.commit();
            return newAccount;
        }
        else {
            return null;
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
        Log.d("MYINFO","Loading my layout");
        LinearLayout linLayout = new LinearLayout(this);
        linLayout.setOrientation(LinearLayout.VERTICAL);
        linLayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        assert linLayout != null;

        TextView textv = new TextView(this);
        textv.setTextSize(20);
        textv.setPadding(15,15,15,15);
        textv.setText("Please insert your ID:");
        textv.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        userid_textfield = new EditText(this);
        userid_textfield.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        //userid_edittext.setText("");

        Button btn = new Button(this);
        btn.setText("Login");
        btn.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        linLayout.addView(textv);
        linLayout.addView(userid_textfield);
        linLayout.addView(btn);

        if (getUserAccount(this.getApplicationContext()) == null) {
            FileLogger.log("Couldn't create user account.", this.getApplicationContext());
            this.finish();
        }

                /* FOR TESTING GRAPH CREATION FROM FILE raw/location_log.log
        AsyncTask.execute(new Runnable() {
            @Override public void run() {
                TestGraphUtils.constructGraph(LocationTrackerActivity.this);
            }
        });
        END FOR TESTING */

        btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                inserted_userid = userid_textfield.getText().toString();
                Log.d("MYINFO", "USER ID:" + inserted_userid);
                // Check that we have permission to get location, if not, ask for permission.
                int permissionCheck =
                        ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION);
                if (permissionCheck != PermissionChecker.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(activity,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            ApplicationConstants.LOCATION_PERMISSIONS_CODE);
                }
                else {
                    // Start the location logging service.
                    Log.d("MYINFO","onClick: Starting Service (we already have permission)");
                    startService(activity.getApplicationContext());
                    activity.finish();
                }
            }
        });

        setContentView(linLayout);

    }

    @Override protected void onResume() {
        super.onResume();
        Log.d("MYINFO","onResume Called");
    }

    @Override protected void onPause() {
        super.onPause();
        Log.d("MYINFO","onPause Called");
    }

    @Override protected void onStart() {
        super.onStart();
        Log.d("MYINFO","onStart Called");

    }

    @Override public void onRequestPermissionsResult(int requestCode,
                                                     @NonNull String permissions[],
                                                     @NonNull int[] grantResults) {
        FileLogger.log("Processing permissions...", this.getApplicationContext());
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == ApplicationConstants.LOCATION_PERMISSIONS_CODE) {
            // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                FileLogger.log("Starting service...", this.getApplicationContext());
                Log.d("MYINFO","onRequestPermissionsResult: Starting Service");
                startService(getApplicationContext());
            }
        }
        this.finish();
    }

    private void startService(final Context context) {
        AsyncTask.execute(new Runnable() {
            @Override public void run() {
                setAlarm(context);
            }
        });
        Intent mServiceIntent = new Intent(this, LocationTrackerService.class);
        WakefulIntentService.sendWakefulWork(context, mServiceIntent);
        CharSequence text = "Location logging now active 1111.";
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    private void setAlarm(Context context) {
        ServiceAlarm alarm = new ServiceAlarm();
        LocationTrackerService.scheduleAlarms(alarm, context);
    }

}

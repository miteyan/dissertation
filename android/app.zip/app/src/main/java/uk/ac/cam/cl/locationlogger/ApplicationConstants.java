package uk.ac.cam.cl.locationlogger;

public class ApplicationConstants {
    public static final boolean DEBUG = true;

    public static final String KEY_UUID = "uuid";
    public static final String ACCOUNT_TYPE = "locationlogger.cl.cam.ac.uk";
    public static final int LOCATION_PERMISSIONS_CODE = 17;
    public static final String TAG = "LocationLogger";

    // LOGGING
    // Measure location every x seconds
    public static final int LOG_INTERVAL_SECONDS = 30;
    public static final long LOG_INTERVAL_MS = LOG_INTERVAL_SECONDS * 1000;
    // Locations less accurate than this are not recorded
    public static final int MIN_ACCURACY_METRES = 10;
    public static final long ACTIVITY_INTERVAL_MS = 10000;
    // We need to be this % sure that the user is moving to log a location
    public static final int ACTIVITY_MOVING_CONFIDENCE = 50;
    // For JSON
    public static final String DEVICE_MODEL = "deviceModel";
    public static final String DEVICE_OPSYS = "deviceOpSys";
    public static final String TIMESTAMP = "timestamp";
    public static final String LOCATION = "location";
    public static final String LOCATION_LATITUDE = "latitude";
    public static final String LOCATION_LONGITUDE = "longitude";
    public static final String ANDROID = "Android";

    // UPLOAD
    public static final String KEY_UPLOAD_TIME = "lastUploadTime";
    // Upload every x minutes, if the phone is connected to WiFi.
    private static final int UPLOAD_INTERVAL_MINUTES = 12*60;
    public static final long UPLOAD_INTERVAL_MILLIS = 1000 * 60 * UPLOAD_INTERVAL_MINUTES;

    // GRAPH CONSTRUCTION (not used, but see TestGraphUtils.java
    // Dwell time required to consider a collection of points a node
    private static final int NEW_LOCATION_TIME_THRESHOLD_MINUTES = 5;
    public static final long NEW_LOCATION_TIME_THRESHOLD_MS =
            1000 * 60 * NEW_LOCATION_TIME_THRESHOLD_MINUTES;
    // Distance outside which a user is considered to have left a node
    public static final int NEW_LOCATION_DISTANCE_THRESHOLD_METRES = 200;
}
